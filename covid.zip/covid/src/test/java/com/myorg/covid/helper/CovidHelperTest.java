package com.myorg.covid.helper;


public class CovidHelperTest {

}
